<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="cs">
    <dependencies>
        <dependency catalog="qtbase_cs"/>
        <dependency catalog="qtscript_cs"/>
        <dependency catalog="qtmultimedia_cs"/>
        <dependency catalog="qtxmlpatterns_cs"/>
    </dependencies>
</TS>
